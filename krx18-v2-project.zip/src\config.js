/**
 * Configuration & Environment Validation
 * --------------------------------------
 * Central place for constants and env var validation.
 * Worker fails fast if required secrets are missing.
 */

// ─── Constants ──────────────────────────────────────────────────

export const CONSTANTS = {
  KRX_BASE: "https://krx18.com",
  KRX_KOREA: "https://krx18.com/genre/korea/",
  USER_AGENT:
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",

  // Cache TTLs (seconds)
  CACHE_TTL: 1800,                  // 30 min — movie list, savelinks
  HOT_CACHE_TTL: 600,               // 10 min — hot movie details
  FAV_TTL: 60 * 60 * 24 * 365,      // 1 year — favorites
  STATS_TTL: 60 * 60 * 24 * 30,     // 30 days — stats counters

  // Timeouts (ms)
  FETCH_TIMEOUT_MS: 12000,
  FETCH_RETRIES: 2,
  FETCH_RETRY_BASE_MS: 500,
  HEAD_TIMEOUT_MS: 8000,
  IMG_TIMEOUT_MS: 15000,

  // Telegram
  TG_API_BASE: "https://api.telegram.org/bot",

  // GitHub
  GH_API_BASE: "https://api.github.com",
  GH_API_VERSION: "2022-11-28",

  // UI
  MOVIES_PER_PAGE: 10,
  MAX_FAVS: 200,
  MAX_REQUEST_TEXT: 500,
  MAX_SYNOPSIS_LEN: 400,
  MAX_CAPTION_LEN: 1024,            // Telegram caption limit

  // Pagination
  MAX_PAGINATION_DEPTH: 100,
};

// ─── Known file hosts (for stats + parsing) ─────────────────────

export const KNOWN_HOSTS = [
  "newsmonth",
  "k2s.cc",
  "nitroflare.com",
  "alterupload.com",
  "keep2share",
  "rapidgator",
  "fileboom",
];

// ─── Filter options ─────────────────────────────────────────────

export const FILTERS = new Set([
  "eng-sub", "engsub",
  "censored", "uncensored",
  "hd", "korea",
]);

// ─── Env validation ─────────────────────────────────────────────

/**
 * Validate required environment variables.
 * Returns { ok, missing, config }.
 */
export function validateEnv(env = {}) {
  const required = ["BOT_TOKEN"];
  const optional = [
    "ADMIN_CHAT_ID",
    "WEBHOOK_SECRET",
    "ALLOWED_USERS",
    "GITHUB_TOKEN",
    "GITHUB_REPO",
    "CACHE_KV",
  ];

  const missing = required.filter((k) => !env[k]);

  const config = {
    botToken: env.BOT_TOKEN,
    adminChatId: env.ADMIN_CHAT_ID,
    webhookSecret: env.WEBHOOK_SECRET,
    allowedUsers: env.ALLOWED_USERS
      ? env.ALLOWED_USERS.split(",").map((s) => s.trim()).filter(Boolean)
      : null,
    githubToken: env.GITHUB_TOKEN,
    githubRepo: env.GITHUB_REPO,
    cacheKv: env.CACHE_KV || null,
  };

  return { ok: missing.length === 0, missing, config };
}

/**
 * Check whether a user is allowed to use the bot.
 * If ALLOWED_USERS is not set, anyone can use it.
 */
export function isUserAllowed(config, userId) {
  if (!config.allowedUsers) return true;
  if (!userId) return false;
  return config.allowedUsers.includes(String(userId));
}
