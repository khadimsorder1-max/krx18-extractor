/**
 * Auto-notify (cron) handler
 * - Fetches latest Korea movies
 * - Sends new releases to admin
 * - Updates "last seen" list in KV
 */

import { CONSTANTS } from "../config.js";
import { fetchText } from "../utils/fetch.js";
import { truncate } from "../utils/text.js";
import { sendPhotoOrText, sendMessage } from "../services/telegram.js";
import { cache, getLastSeen, setLastSeen, createMovieList } from "../services/cache.js";
import { parseMovieList } from "../parsers/movieList.js";
import { parseMovieDetails } from "../parsers/movieDetails.js";
import * as logger from "../utils/logger.js";

function esc(s) {
  if (!s) return "";
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

export async function handleScheduled(config) {
  if (!config.adminChatId || !config.botToken) return;
  const r = await fetchText(CONSTANTS.KRX_KOREA);
  if (!r.ok) return;
  const movies = parseMovieList(r.text);
  if (movies.length === 0) return;

  const lastSeen = await getLastSeen(config.cacheKv);
  const newMovies = movies.filter((m) => !lastSeen.includes(m.slug));
  if (newMovies.length === 0) {
    logger.info("Auto-notify: no new movies");
    return;
  }
  logger.info("Auto-notify: new movies found", { count: newMovies.length });

  for (const m of newMovies.slice(0, 5)) {
    try {
      let details = await cache.getJson(config.cacheKv, `movie:${m.slug}`);
      if (!details) {
        const dr = await fetchText(m.url);
        if (dr.ok) {
          details = parseMovieDetails(dr.text);
          details.movieUrl = m.url;
          await cache.setJson(config.cacheKv, `movie:${m.slug}`, details, CONSTANTS.CACHE_TTL * 4);
        }
      }
      const info = details;
      let caption = `🆕 <b>New Korea Release!</b>\n\n🎬 ${esc(m.title)}\n`;
      if (info?.quality) caption += `🎥 Quality: ${esc(info.quality)}\n`;
      if (details?.releaseDate) caption += `📅 Release: ${esc(details.releaseDate)}\n`;
      if (details?.genres?.length > 0) caption += `🎭 Genres: ${esc(details.genres.join(", "))}\n`;
      if (details?.uploadDate) caption += `🕒 Uploaded: ${esc(details.uploadDate)}\n`;
      if (m.synopsis) caption += `\n📖 ${esc(truncate(m.synopsis, 300))}\n`;
      caption += `\n🔗 ${esc(m.url)}`;

      const listId = await createMovieList(config.cacheKv, [m.slug]);
      const keyboard = [[{ text: "🎬 View Details & Download", callback_data: `movie:${listId}:0` }]];

      await sendPhotoOrText(
        config.botToken, config.adminChatId, m.poster, caption,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: keyboard } }
      );
    } catch (e) {
      logger.error("Auto-notify: error sending", { slug: m.slug, error: String(e) });
    }
  }

  const newLastSeen = movies.map((m) => m.slug).concat(lastSeen).slice(0, 100);
  await setLastSeen(config.cacheKv, newLastSeen);
}
