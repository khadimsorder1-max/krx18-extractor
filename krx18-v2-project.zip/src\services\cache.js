/**
 * KV-based cache service
 * - JSON value helpers
 * - String value helpers (for stats counters)
 * - No-op if KV binding missing
 */

import { CONSTANTS } from "../config.js";

async function getJson(kv, key) {
  if (!kv) return null;
  try {
    const v = await kv.get(key, "json");
    return v ?? null;
  } catch {
    return null;
  }
}

async function setJson(kv, key, value, ttl = CONSTANTS.CACHE_TTL) {
  if (!kv) return;
  try {
    await kv.put(key, JSON.stringify(value), { expirationTtl: ttl });
  } catch {}
}

async function getString(kv, key) {
  if (!kv) return null;
  try {
    return await kv.get(key);
  } catch {
    return null;
  }
}

async function setString(kv, key, value, ttl = CONSTANTS.CACHE_TTL) {
  if (!kv) return;
  try {
    await kv.put(key, value, { expirationTtl: ttl });
  } catch {}
}

// Public API
export const cache = {
  getJson,
  setJson,
  getString,
  setString,
};

// ─── Favorites ──────────────────────────────────────────────────

export async function getFavorites(kv, userId) {
  const v = await getJson(kv, `fav:${userId}`);
  return Array.isArray(v) ? v : [];
}

export async function addFavorite(kv, userId, slug, title) {
  const favs = await getFavorites(kv, userId);
  if (favs.find((f) => f.slug === slug)) return favs;
  favs.push({ slug, title, added_at: new Date().toISOString() });
  // Cap favorites list size
  if (favs.length > CONSTANTS.MAX_FAVS) favs.shift();
  await setJson(kv, `fav:${userId}`, favs, CONSTANTS.FAV_TTL);
  return favs;
}

export async function removeFavorite(kv, userId, slug) {
  const favs = await getFavorites(kv, userId);
  const filtered = favs.filter((f) => f.slug !== slug);
  await setJson(kv, `fav:${userId}`, filtered, CONSTANTS.FAV_TTL);
  return filtered;
}

// ─── Movie list index (for safe callback_data) ──────────────────

// Store slug array under a short ID; returns ID for use in callback_data
export async function createMovieList(kv, slugs) {
  const id = Date.now().toString(36);
  await setJson(kv, `klist:${id}`, slugs, CONSTANTS.CACHE_TTL);
  return id;
}

// ─── Last-seen (auto-notify) ────────────────────────────────────

export async function getLastSeen(kv) {
  const v = await getJson(kv, "notify:last_seen");
  return Array.isArray(v) ? v : [];
}

export async function setLastSeen(kv, slugs) {
  await setJson(kv, "notify:last_seen", slugs, CONSTANTS.STATS_TTL);
}
