/**
 * Direct stream handler
 * - Triggers GitHub Actions (Puppeteer extractor)
 * - Sends "processing" message → edits with result later (Action does the edit)
 */

import { CONSTANTS } from "../config.js";
import { esc } from "../utils/text.js";
import { sendMessage, editMessageText } from "../services/telegram.js";
import { dispatchEvent } from "../services/github.js";
import * as logger from "../utils/logger.js";

export async function handleDirectStream(config, chatId, slug, server, userId, reqId) {
  const movieUrl = `${CONSTANTS.KRX_BASE}/movies/${slug}/`;

  if (!config.githubToken || !config.githubRepo) {
    await sendMessage(
      config.botToken, chatId,
      `❌ <b>Direct stream configured নন!</b>\n\nWorker এ <code>GITHUB_TOKEN</code> এবং <code>GITHUB_REPO</code> secret set করুন।\n\nSetup এর জন্য README দেখুন।`,
      { parse_mode: "HTML" }
    );
    return;
  }

  // Send processing message
  const procMsg = await sendMessage(
    config.botToken, chatId,
    `⏳ <b>Direct video URL বের করা হচ্ছে...</b>\n\n` +
    `🎬 Server ${esc(server)}\n` +
    `🔄 GitHub Actions এ Puppeteer trigger করা হচ্ছে...\n` +
    `⏱️ সময় লাগবে 30-60 সেকেন্ড\n\n` +
    `<i>এই message টা আপনার edit হবে যখন URL পাওয়া যাবে</i>`,
    { parse_mode: "HTML" }
  );
  const procMessageId = procMsg?.result?.message_id;

  // Trigger GitHub Action
  const result = await dispatchEvent(config, "extract_video", {
    movie_url: movieUrl,
    chat_id: String(chatId),
    message_id: String(procMessageId || ""),
    server: String(server),
    user_id: String(userId || ""),
    slug,
  }, reqId);

  if (result.ok) {
    await editMessageText(
      config.botToken, chatId, procMessageId,
      `⏳ <b>Processing...</b>\n\n` +
      `✅ GitHub Action triggered!\n` +
      `🔄 Puppeteer browser খুলছে...\n` +
      `⏱️ 30-60s অপেক্ষা করুন\n\n` +
      `<i>URL প্রস্তুত হলে এই message টা আপডেট হবে</i>`,
      { parse_mode: "HTML" }
    );
  } else {
    logger.warn("GitHub dispatch failed", { error: result.error }, reqId);
    await editMessageText(
      config.botToken, chatId, procMessageId,
      `❌ <b>GitHub Actions trigger failed!</b>\n\n<code>${esc((result.error || "").slice(0, 200))}</code>`,
      { parse_mode: "HTML" }
    );
  }
}
