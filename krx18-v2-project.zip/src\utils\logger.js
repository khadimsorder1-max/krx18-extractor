/**
 * Structured logger
 * - Uses console.log (Worker env) and console.error
 * - Optional debug level via env.DEBUG
 * - Request IDs for tracing
 */

const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };

function currentLevel() {
  // env not always available at module load; check on each call
  try {
    if (typeof self !== "undefined" && self.env && self.env.DEBUG) return LEVELS.debug;
  } catch {}
  return LEVELS.info;
}

function fmt(level, msg, meta, reqId) {
  const ts = new Date().toISOString();
  const base = `[${ts}] [${level.toUpperCase()}]${reqId ? ` [req=${reqId}]` : ""} ${msg}`;
  if (meta && Object.keys(meta).length > 0) {
    return `${base} ${JSON.stringify(meta)}`;
  }
  return base;
}

export function debug(msg, meta = {}, reqId) {
  if (currentLevel() <= LEVELS.debug) console.log(fmt("debug", msg, meta, reqId));
}

export function info(msg, meta = {}, reqId) {
  console.log(fmt("info", msg, meta, reqId));
}

export function warn(msg, meta = {}, reqId) {
  console.warn(fmt("warn", msg, meta, reqId));
}

export function error(msg, meta = {}, reqId) {
  console.error(fmt("error", msg, meta, reqId));
}

// Generate short request ID
export function newReqId() {
  return Math.random().toString(36).slice(2, 10);
}
