/**
 * Worker entry point — router
 * - /webhook        → Telegram webhook
 * - /health         → health check JSON
 * - /img/<b64>      → image proxy
 * - /               → status page
 */

import { CONSTANTS, validateEnv, FILTERS } from "./config.js";
import { newReqId, info, error } from "./utils/logger.js";
import { fetchBinary } from "./utils/fetch.js";
import { b64decode } from "./utils/text.js";

import { checkWebhookSecret } from "./middleware/webhook.js";
import { checkUser } from "./middleware/auth.js";
import { safeCallback } from "./utils/validate.js";

import { sendMessage, answerCallback } from "./services/telegram.js";
import { cache } from "./services/cache.js";
import { handleStart } from "./handlers/start.js";
import { handleLatest } from "./handlers/latest.js";
import { handleSearch, handleInline } from "./handlers/search.js";
import { handleMovieDetails } from "./handlers/movie.js";
import {
  handleAddFavorite, handleListFavorites, handleRemoveFavorite,
} from "./handlers/favorites.js";
import { handleSimilar } from "./handlers/similar.js";
import { handleRequest } from "./handlers/request.js";
import { handleStats } from "./handlers/stats.js";
import { handleScheduled } from "./handlers/notify.js";

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const reqId = newReqId();
    const { config } = validateEnv(env);

    // CORS preflight
    if (request.method === "OPTIONS") {
      return new Response(null, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Methods": "GET, OPTIONS",
          "Access-Control-Allow-Headers": "*",
        },
      });
    }

    try {
      // ─── /webhook ───
      if (url.pathname === "/webhook") {
        if (!checkWebhookSecret(config, url)) {
          return new Response("Forbidden", { status: 403 });
        }
        return await handleWebhook(request, env, config, url, reqId);
      }

      // ─── /health ───
      if (url.pathname === "/health") {
        return handleHealth(env, config);
      }

      // ─── /img/<b64> ───
      const imgMatch = url.pathname.match(/^\/img\/([A-Za-z0-9_-]+)$/);
      if (imgMatch) {
        return handleImageProxy(imgMatch[1], config);
      }

      // ─── / (status page) ───
      if (url.pathname === "/" || url.pathname === "") {
        return handleStatusPage(url, env, config);
      }

      return new Response("Not found", { status: 404 });
    } catch (e) {
      error("Unhandled error", { path: url.pathname, error: String(e) }, reqId);
      return new Response("Internal error", { status: 500 });
    }
  },

  async scheduled(event, env, ctx) {
    const { config } = validateEnv(env);
    ctx.waitUntil(handleScheduled(config));
  },
};

// ─── Webhook handler ────────────────────────────────────────────

async function handleWebhook(request, env, config, url, reqId) {
  if (!config.botToken) return new Response("BOT_TOKEN not set", { status: 500 });
  config.workerUrl = url.origin;

  let update;
  try {
    update = await request.json();
  } catch {
    return new Response("Invalid JSON", { status: 400 });
  }

  // ─── Inline query ───
  if (update.inline_query) {
    await handleInline(config, update.inline_query);
    return new Response("OK");
  }

  // ─── Callback query ───
  if (update.callback_query) {
    const cq = update.callback_query;
    const data = safeCallback(cq.data);
    const chatId = cq.message?.chat?.id;
    const { allowed, userId } = checkUser(config, cq.from);

    if (!data) {
      await answerCallback(config.botToken, cq.id, "❌ Invalid request");
      return new Response("OK");
    }
    if (!allowed) {
      await answerCallback(config.botToken, cq.id, "❌ অনুমতি নেই");
      return new Response("OK");
    }
    if (data === "noop") {
      await answerCallback(config.botToken, cq.id, "");
      return new Response("OK");
    }

    await answerCallback(config.botToken, cq.id, "⏳ লোড হচ্ছে...");

    try {
      if (data.startsWith("latest:")) {
        const parts = data.split(":");
        const page = parseInt(parts[1], 10) || 1;
        const filter = parts[2] || null;
        await handleLatest(config, chatId, page, filter, reqId);
      } else if (data.startsWith("movie:")) {
        const parts = data.split(":");
        let slug = null;
        if (parts.length === 3 && /^\d+$/.test(parts[2])) {
          const index = parseInt(parts[2], 10);
          const listKey = parts[1];
          // Try klist:{listKey} first (search, similar, favs, notify)
          const klistSlugs = await cache.getJson(config.cacheKv, `klist:${listKey}`);
          if (Array.isArray(klistSlugs)) {
            slug = klistSlugs[index] || null;
          } else {
            // Fallback: try korea_latest_p{page} (from /latest)
            const pageMovies = await cache.getJson(config.cacheKv, `korea_latest_p${listKey}`);
            if (Array.isArray(pageMovies)) {
              slug = pageMovies[index]?.slug || null;
            }
          }
        }
        if (!slug) {
          // Legacy fallback: movie:{slug}
          slug = parts[1];
        }
        if (slug) {
          await handleMovieDetails(config, chatId, slug, userId, reqId);
        }
      } else if (data.startsWith("similar:")) {
        const parts = data.split(":");
        let slug = null;
        if (parts.length === 3 && /^\d+$/.test(parts[2])) {
          const listId = parts[1];
          const index = parseInt(parts[2], 10);
          const slugs = await cache.getJson(config.cacheKv, `klist:${listId}`);
          slug = Array.isArray(slugs) ? slugs[index] : null;
        }
        if (!slug) slug = parts[1];
        if (slug) await handleSimilar(config, chatId, slug, reqId);
      } else if (data.startsWith("addfav:")) {
        const parts = data.split(":");
        let slug = null, title = "";
        if (parts.length === 3 && /^\d+$/.test(parts[2])) {
          const listId = parts[1];
          const index = parseInt(parts[2], 10);
          const entries = await cache.getJson(config.cacheKv, `klist:${listId}`);
          if (Array.isArray(entries) && entries[index]) {
            const sep = entries[index].indexOf(":");
            slug = entries[index].slice(0, sep);
            title = entries[index].slice(sep + 1);
          }
        }
        if (!slug) {
          slug = parts[1];
          title = parts.slice(2).join(":");
        }
        if (slug) await handleAddFavorite(config, chatId, slug, title, userId);
      } else if (data.startsWith("mlist:")) {
        const parts = data.split(":");
        if (parts.length === 3) {
          const listId = parts[1];
          const index = parseInt(parts[2], 10);
          const slugs = await cache.getJson(config.cacheKv, `klist:${listId}`);
          const slug = Array.isArray(slugs) ? slugs[index] : null;
          if (slug) {
            await handleMovieDetails(config, chatId, slug, userId, reqId);
          }
        }
      }
    } catch (e) {
      error("Callback handler failed", { data, error: String(e) }, reqId);
    }
    return new Response("OK");
  }

  // ─── Message ───
  if (update.message) {
    const msg = update.message;
    const chatId = msg.chat.id;
    const { allowed, userId, username } = checkUser(config, msg.from);
    const text = msg.text || "";

    if (!allowed) {
      await sendMessage(config.botToken, chatId, "❌ অনুমতি নেই");
      return new Response("OK");
    }

    try {
      await handleMessage(config, chatId, text, userId, username, reqId);
    } catch (e) {
      error("Message handler failed", { text: text.slice(0, 100), error: String(e) }, reqId);
    }
  }

  return new Response("OK");
}

async function handleMessage(config, chatId, text, userId, username, reqId) {
  if (text.startsWith("/start") || text.startsWith("/help")) {
    await handleStart(config, chatId);
  } else if (text.startsWith("/latest")) {
    const { page, filter } = parseLatestArgs(text);
    await handleLatest(config, chatId, page, filter, reqId);
  } else if (text.startsWith("/search ")) {
    await handleSearch(config, chatId, text.slice("/search ".length).trim());
  } else if (text.startsWith("/movie ")) {
    const url = text.slice("/movie ".length).trim();
    const slug = url.replace(/\/$/, "").split("/").pop();
    await handleMovieDetails(config, chatId, slug, userId, reqId);
  } else if (text.startsWith("/fav ")) {
    const slug = text.slice("/fav ".length).trim().replace(/\/$/, "").split("/").pop();
    const cached = await config.cacheKv?.get(`movie:${slug}`, "json");
    const title = cached?.title || slug;
    await handleAddFavorite(config, chatId, slug, title, userId);
  } else if (text.startsWith("/favs")) {
    await handleListFavorites(config, chatId, userId);
  } else if (text.startsWith("/unfav ")) {
    const slug = text.slice("/unfav ".length).trim().replace(/\/$/, "").split("/").pop();
    await handleRemoveFavorite(config, chatId, slug, userId);
  } else if (text.startsWith("/request ")) {
    await handleRequest(config, chatId, text.slice("/request ".length).trim(), userId, username);
  } else if (text.startsWith("/stats")) {
    await handleStats(config, chatId);
  } else if (text.trim().length > 1) {
    await handleSearch(config, chatId, text.trim());
  }
}

function parseLatestArgs(text) {
  const parts = text.split(/\s+/);
  let page = 1;
  let filter = null;
  for (let i = 1; i < parts.length; i++) {
    const arg = parts[i].toLowerCase();
    if (/^\d+$/.test(arg)) page = parseInt(arg, 10);
    else if (FILTERS.has(arg)) filter = arg;
  }
  return { page, filter };
}

// ─── Image proxy ────────────────────────────────────────────────

async function handleImageProxy(b64, config) {
  let url;
  try {
    url = b64decode(b64);
  } catch {
    return new Response("Invalid", { status: 400 });
  }
  const r = await fetchBinary(url, { Accept: "image/*" });
  if (!r.ok) return new Response("Fetch failed", { status: 502 });
  return new Response(r.body, {
    headers: {
      "Content-Type": r.contentType || "image/jpeg",
      "Cache-Control": "public, max-age=86400",
      "Access-Control-Allow-Origin": "*",
    },
  });
}

// ─── Health ─────────────────────────────────────────────────────

function handleHealth(env, config) {
  return new Response(
    JSON.stringify(
      {
        status: "OK",
        timestamp: new Date().toISOString(),
        bot: "KRX18 Korea Bot v2",
        kv: !!config.cacheKv,
        admin_configured: !!config.adminChatId,
        github_configured: !!(config.githubToken && config.githubRepo),
        allowed_users: config.allowedUsers ? config.allowedUsers.length : "anyone",
      },
      null,
      2
    ),
    { headers: { "Content-Type": "application/json" } }
  );
}

// ─── Status page ────────────────────────────────────────────────

function handleStatusPage(url, env, config) {
  const webhookHint = config.webhookSecret ? `?token=${config.webhookSecret}` : "";
  const body =
    `🎬 KRX18 Korea Bot v2\n\n` +
    `Status: ${config.botToken ? "✅" : "❌"} BOT_TOKEN\n` +
    `Admin: ${config.adminChatId ? "✅" : "❌"}\n` +
    `KV: ${config.cacheKv ? "✅" : "❌"}\n` +
    `GitHub: ${config.githubToken && config.githubRepo ? "✅" : "❌"}\n` +
    `Whitelist: ${config.allowedUsers ? config.allowedUsers.length + " users" : "anyone"}\n\n` +
    `Setup:\n` +
    `1. Set webhook:\n` +
    `   https://api.telegram.org/bot<TOKEN>/setWebhook?url=https://${url.host}/webhook${webhookHint}\n` +
    `2. Add cron in wrangler.toml:\n` +
    `   [triggers]\n   crons = ["*/30 * * * *"]`;
  return new Response(body, { headers: { "Content-Type": "text/plain" } });
}
