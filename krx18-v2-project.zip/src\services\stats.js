/**
 * Download stats service
 * - Total / per-user / per-host / daily counters
 * - Stored in KV as strings (counters)
 */

import { CONSTANTS, KNOWN_HOSTS } from "../config.js";

async function increment(kv, key, ttl = CONSTANTS.STATS_TTL) {
  if (!kv) return;
  const cur = parseInt((await kv.get(key)) || "0", 10);
  await kv.put(key, String(cur + 1), { expirationTtl: ttl });
}

export async function recordDownload(kv, userId, host) {
  if (!kv) return;
  const today = new Date().toISOString().slice(0, 10);
  await increment(kv, "stats:total");
  await increment(kv, `stats:user:${userId}`);
  await increment(kv, `stats:host:${host}`);
  await increment(kv, `stats:daily:${today}`);
}

export async function getStats(kv) {
  if (!kv) return null;
  const total = parseInt((await kv.get("stats:total")) || "0", 10);

  const hosts = {};
  for (const h of KNOWN_HOSTS) {
    const c = parseInt((await kv.get(`stats:host:${h}`)) || "0", 10);
    if (c > 0) hosts[h] = c;
  }

  const daily = {};
  const now = new Date();
  for (let i = 0; i < 7; i++) {
    const d = new Date(now.getTime() - i * 86400000).toISOString().slice(0, 10);
    const c = parseInt((await kv.get(`stats:daily:${d}`)) || "0", 10);
    if (c > 0) daily[d] = c;
  }

  return { total, hosts, daily };
}
