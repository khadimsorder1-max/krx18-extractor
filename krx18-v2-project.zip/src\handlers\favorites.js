/**
 * Favorites handler
 * - /fav, /favs, /unfav
 * - Buttons on movie page
 */

import { sendMessage } from "../services/telegram.js";
import {
  getFavorites, addFavorite, removeFavorite, createMovieList,
} from "../services/cache.js";
import { esc } from "../utils/text.js";

export async function handleAddFavorite(config, chatId, slug, title, userId) {
  if (!userId) {
    await sendMessage(config.botToken, chatId, "❌ User ID detect করা যায়নি");
    return;
  }
  await addFavorite(config.cacheKv, userId, slug, title);
  await sendMessage(
    config.botToken, chatId,
    `⭐ <b>Favorite এ যোগ হয়েছে!</b>\n\n🎬 ${esc(title)}`,
    { parse_mode: "HTML" }
  );
}

export async function handleListFavorites(config, chatId, userId) {
  if (!userId) {
    await sendMessage(config.botToken, chatId, "❌ User ID detect করা যায়নি");
    return;
  }
  const favs = await getFavorites(config.cacheKv, userId);
  if (favs.length === 0) {
    await sendMessage(
      config.botToken, chatId,
      "📭 তোমার favorite list খালি\n\n/movie url দিয়ে movie details খুলে '⭐ Add to Favorites' চাপো"
    );
    return;
  }
  const listId = await createMovieList(config.cacheKv, favs.map(f => f.slug));
  const keyboard = buildFavKeyboard(favs, listId);
  await sendMessage(
    config.botToken, chatId,
    `⭐ <b>তোমার Favorites</b> (${favs.length})`,
    { parse_mode: "HTML", reply_markup: { inline_keyboard: keyboard } }
  );
}

export async function handleRemoveFavorite(config, chatId, slug, userId) {
  if (!userId) {
    await sendMessage(config.botToken, chatId, "❌ User ID detect করা যায়নি");
    return;
  }
  await removeFavorite(config.cacheKv, userId, slug);
  await sendMessage(config.botToken, chatId, "✅ Favorite থেকে সরানো হয়েছে");
}

function buildFavKeyboard(favs, listId) {
  const keyboard = [];
  for (let i = 0; i < favs.length; i += 2) {
    const row = [];
    for (let j = i; j < Math.min(i + 2, favs.length); j++) {
      const title = favs[j].title.length > 30
        ? favs[j].title.slice(0, 30) + "…"
        : favs[j].title;
      row.push({ text: `🎬 ${title}`, callback_data: `movie:${listId}:${j}` });
    }
    keyboard.push(row);
  }
  return keyboard;
}
