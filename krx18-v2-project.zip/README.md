# KRX18 Korea Bot v2 — Refactored & Modular

> **Telegram bot** for `krx18.com/genre/korea/` — built with Cloudflare Workers + GitHub Actions (Puppeteer).
>
> This is the **refactored v2** — cleaner architecture, better error handling, structured logging, modular code, tests, and full documentation.

## ✨ What's New in v2

Compared to v1, this version is **completely refactored** following the improvement plan:

| Area | v1 | v2 |
|------|----|----|
| Structure | Single 1000+ line file | **Modular**: 18 files across 6 folders |
| Config | Hardcoded constants | `src/config.js` + env validation |
| Logging | `console.log` everywhere | Structured logger with timestamps + request IDs |
| Error handling | Try/catch in handlers | Global error handler + retry with backoff |
| Tests | None | Unit tests for text/validate/config/parsers |
| Validation | None | Slug/URL/filter/page/callback validators |
| Docs | Single README | README + ARCHITECTURE + DEPLOYMENT + TROUBLESHOOTING |
| Linting | None | ESLint + Prettier configs |
| Caching | Inline | Centralized `services/cache.js` |
| Extractor | Single 400-line file | 4 modules (browser, capture, notify, index) |

## 📁 Project Structure

```
krx18-v2/
├── .github/workflows/
│   └── extract-video.yml        ← GitHub Actions (with retry + cache)
├── src/                          ← Cloudflare Worker
│   ├── index.js                  ← Entry + router
│   ├── config.js                 ← Constants + env validation
│   ├── middleware/
│   │   ├── auth.js              ← User whitelist
│   │   └── webhook.js           ← Webhook secret
│   ├── handlers/
│   │   ├── start.js             ← /start, /help
│   │   ├── latest.js            ← /latest [filter] [page]
│   │   ├── search.js            ← /search + inline
│   │   ├── movie.js             ← Movie details
│   │   ├── direct.js            ← Watch Online Direct
│   │   ├── favorites.js         ← /fav, /favs, /unfav
│   │   ├── similar.js           ← Same genre
│   │   ├── request.js           ← /request
│   │   ├── stats.js             ← /stats
│   │   └── notify.js            ← Cron auto-notify
│   ├── services/
│   │   ├── telegram.js          ← Bot API client
│   │   ├── cache.js             ← KV + favorites
│   │   ├── github.js            ← repository_dispatch
│   │   └── stats.js             ← Download counters
│   ├── parsers/
│   │   ├── movieList.js         ← Listing parser
│   │   └── movieDetails.js      ← Details + JSON-LD
│   └── utils/
│       ├── fetch.js             ← fetchText/Binary/Head + retry
│       ├── text.js              ← escapeMd, decodeEntities, b64
│       ├── validate.js          ← URL/slug/filter validators
│       └── logger.js            ← Structured logging
├── extractor/                    ← GitHub Actions Puppeteer
│   ├── index.js                  ← Main orchestrator
│   ├── browser.js                ← Launch (stealth + adblocker)
│   ├── capture.js                ← Network interception
│   ├── notify.js                 ← Telegram edit
│   └── package.json
├── tests/
│   ├── text.test.js
│   ├── validate.test.js
│   ├── config.test.js
│   └── movieList.test.js
├── docs/
│   ├── ARCHITECTURE.md
│   ├── DEPLOYMENT.md
│   └── TROUBLESHOOTING.md
├── .env.example
├── .eslintrc.json
├── .prettierrc
├── .gitignore
├── package.json
├── wrangler.toml
└── README.md                     ← This file
```

## 🎯 Features

### Bot commands

| Command | Description |
|---------|-------------|
| `/start` | Welcome + help |
| `/latest [filter] [page]` | Latest Korean movies |
| `/search <query>` | Search movies |
| `/movie <url>` | Specific movie details |
| `/fav <slug>` | Add to favorites |
| `/favs` | List favorites |
| `/unfav <slug>` | Remove favorite |
| `/request <name>` | Request movie to admin |
| `/stats` | Download statistics |
| `@bot <query>` | Inline mode (any chat) |

### Filters

`/latest` accepts:

- `eng-sub` — English subtitled
- `censored` — Censored only
- `uncensored` — Uncensored only
- `hd` — HD quality only
- `korea` — Korea category

### Movie details page shows

- 🎬 Title (English + Korean Hangul)
- 🖼️ Poster
- 📅 Release date
- 🌍 Country
- 🎭 Genres
- 🎥 Quality badge
- 👥 Cast
- 📖 Synopsis
- ▶️ Trailer (if available)

### Download options

- **▶️ Watch Online Direct** — triggers GitHub Action → Puppeteer extracts direct `.mp4`/`.m3u8` URL (30-60s, no ads)
- **⬇️ Download** — opens `newsmonth.today` redirect → file host (k2s.cc / nitroflare / alterupload)
- **🎭 Similar Movies** — same genre recommendations
- **⭐ Add to Favorites**

### Other features

- **Auto-notify** — cron every 30 min, sends new releases to admin
- **User whitelist** — restrict bot to specific Telegram user IDs
- **Webhook secret** — prevent fake webhook requests
- **Image proxy** — `/img/<b64>` endpoint for poster fallback
- **Health check** — `/health` endpoint with JSON status
- **Structured logging** — timestamps + request IDs
- **KV caching** — movie list + details cached
- **Stats** — total / per-host / daily download counts

## 🚀 Quick Start

See **[docs/DEPLOYMENT.md](docs/DEPLOYMENT.md)** for full step-by-step guide.

Short version:

1. Create Telegram bot via @BotFather
2. Create GitHub repo `krx18-extractor` → upload `extractor/` + `.github/workflows/`
3. Add `BOT_TOKEN` secret to GitHub repo
4. Create GitHub PAT (repo scope)
5. Deploy Cloudflare Worker:
   ```bash
   wrangler kv namespace create CACHE_KV
   # Edit wrangler.toml → paste KV id
   wrangler secret put BOT_TOKEN
   wrangler secret put ADMIN_CHAT_ID
   wrangler secret put GITHUB_TOKEN
   wrangler secret put GITHUB_REPO
   wrangler deploy
   ```
6. Set webhook:
   ```
   https://api.telegram.org/bot<TOKEN>/setWebhook?url=https://<WORKER>/webhook?token=<SECRET>
   ```
7. Send `/latest` to your bot

## 🧪 Testing

```bash
npm test
```

Runs unit tests for:

- Text utilities (entity decode, MarkdownV2 escape, base64)
- Validators (URL, slug, filter, page, callback data)
- Config + env validation
- Movie list parser

## 🛠️ Development

```bash
# Install deps
npm install

# Lint
npm run lint

# Format
npm run format

# Local dev
npm run dev

# Tail logs
npm run tail
```

## 📊 Cost

| Resource | Free Tier | Usage |
|----------|-----------|-------|
| Cloudflare Workers | 100k req/day | ~3-5 req per movie |
| Cloudflare KV | 100k reads + 1k writes/day | Caching |
| GitHub Actions (public) | **Unlimited** | ~40s per extraction |
| Telegram Bot API | Free | Unlimited |
| **Total** | **$0** | ✅ |

## 📚 Documentation

- **[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)** — System architecture + data flow
- **[docs/DEPLOYMENT.md](docs/DEPLOYMENT.md)** — Full deployment guide
- **[docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)** — Common issues + fixes

## ⚠️ Legal Note

This bot is for personal use only. Content copyright is the user's responsibility. The bot is a link aggregator — it does not host any content.
