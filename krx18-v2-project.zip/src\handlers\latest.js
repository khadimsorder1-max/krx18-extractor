/**
 * /latest handler
 * - Poster gallery (media group) + numbered keyboard
 * - Pagination + filters
 */

import { CONSTANTS, FILTERS } from "../config.js";
import { fetchText } from "../utils/fetch.js";
import { sendMessage, sendMediaGroup } from "../services/telegram.js";
import { cache, createMovieList } from "../services/cache.js";
import { parseMovieList, filterMovies } from "../parsers/movieList.js";
import { isValidPage, isValidFilter } from "../utils/validate.js";
import { esc, proxyPoster } from "../utils/text.js";
import * as logger from "../utils/logger.js";

export async function handleLatest(config, chatId, page = 1, filter = null, reqId) {
  if (!isValidPage(page)) {
    await sendMessage(config.botToken, chatId, "❌ Invalid page number");
    return;
  }
  if (filter && !isValidFilter(filter)) {
    await sendMessage(config.botToken, chatId, `❌ Invalid filter. Options: ${[...FILTERS].join(", ")}`);
    return;
  }

  const cacheKey = `korea_latest_p${page}`;
  let movies = await cache.getJson(config.cacheKv, cacheKey);
  if (!movies) {
    const url = page === 1 ? CONSTANTS.KRX_KOREA : `${CONSTANTS.KRX_KOREA}page/${page}/`;
    logger.info("Fetching latest movies", { page, url }, reqId);
    const r = await fetchText(url);
    if (!r.ok) {
      logger.warn("Latest fetch failed", { status: r.status }, reqId);
      await sendMessage(config.botToken, chatId, "❌ krx18 fetch করা যায়নি। পরে চেষ্টা করো।");
      return;
    }
    movies = parseMovieList(r.text);
    await cache.setJson(config.cacheKv, cacheKey, movies, CONSTANTS.CACHE_TTL);
  }

  if (filter) movies = filterMovies(movies, filter);

  if (movies.length === 0) {
    await sendMessage(config.botToken, chatId, "❌ কোনো movie পাওয়া যায়নি");
    return;
  }

  const top = movies.slice(0, CONSTANTS.MOVIES_PER_PAGE);

  const listId = await createMovieList(config.cacheKv, top.map(m => m.slug));

  // Step 1: Send poster gallery (media group)
  await sendGallery(config, chatId, top, listId, page);

  // Step 2: Send numbered keyboard + pagination
  await sendKeyboard(config, chatId, top, listId, page, filter);
}

async function sendGallery(config, chatId, movies, listId, page) {
  const workerUrl = config.workerUrl || "";
  const media = movies.map((m, i) => {
    const photo = m.poster ? proxyPoster(m.poster, workerUrl) : "";
    const parts = [];
    parts.push(`${i + 1}/${movies.length} 🎬 <b>${esc(m.title)}</b>`);
    if (m.year || m.releaseDate) parts.push(`📅 ${esc(m.year || m.releaseDate)}`);
    if (m.quality) parts.push(`🎥 ${esc(m.quality)}`);
    if (m.genres && m.genres.length > 0) parts.push(`🎭 ${esc(m.genres.slice(0, 3).join(", "))}`);
    if (m.synopsis) {
      const syn = m.synopsis.length > 150 ? m.synopsis.slice(0, 150) + "…" : m.synopsis;
      parts.push(`\n📖 ${esc(syn)}`);
    }

    const item = {
      type: "photo",
      caption: parts.join("\n"),
      parse_mode: "HTML",
    };
    if (photo) {
      item.photo = photo;
    } else {
      // No poster — use a placeholder or skip
      item.photo = "https://via.placeholder.com/300x450?text=No+Poster";
    }
    return item;
  });

  // Telegram media group requires 2-10 items
  if (media.length >= 2) {
    const result = await sendMediaGroup(config.botToken, chatId, media);
    if (!result.ok) {
      // Fallback: send as individual photos (best effort)
      logger.warn("sendMediaGroup failed, trying individual photos", { error: result.description });
    }
  } else if (media.length === 1) {
    // Single item — send as regular photo
    const { sendPhoto } = await import("../services/telegram.js");
    await sendPhoto(config.botToken, chatId, media[0].photo, media[0].caption, { parse_mode: "HTML" });
  }
}

async function sendKeyboard(config, chatId, movies, listId, page, filter) {
  const keyboard = buildKeyboard(movies, listId, page, filter);
  const filterText = filter ? ` (${filter})` : "";
  const totalMovies = movies.length;
  const pageNums = [];
  for (let i = 1; i <= totalMovies; i++) {
    pageNums.push(`${i}️⃣`);
  }

  await sendMessage(
    config.botToken,
    chatId,
    `🎬 <b>Korea Movies</b> (Page ${page})${filterText} — ${totalMovies} movies\n\n` +
    `বাটনে চাপো movie details দেখতে:`,
    { parse_mode: "HTML", reply_markup: { inline_keyboard: keyboard } }
  );
}

function buildKeyboard(movies, listId, page, filter) {
  const emojis = ["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣","🔟"];
  const keyboard = [];

  // Movie buttons in rows of 5
  for (let i = 0; i < movies.length; i += 5) {
    const row = [];
    for (let j = i; j < Math.min(i + 5, movies.length); j++) {
      const title = movies[j].title.length > 20
        ? movies[j].title.slice(0, 20) + "…"
        : movies[j].title;
      row.push({
        text: `${emojis[j]} ${title}`,
        callback_data: `mlist:${listId}:${j}`,
      });
    }
    keyboard.push(row);
  }

  // Navigation row
  const navRow = [];
  if (page > 1) {
    navRow.push({ text: "⬅️ Prev", callback_data: `latest:${page - 1}${filter ? ":" + filter : ""}` });
  }
  navRow.push({ text: `📄 Page ${page}`, callback_data: "noop" });
  navRow.push({ text: "Next ➡️", callback_data: `latest:${page + 1}${filter ? ":" + filter : ""}` });
  keyboard.push(navRow);

  return keyboard;
}
