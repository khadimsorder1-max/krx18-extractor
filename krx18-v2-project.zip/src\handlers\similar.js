/**
 * Similar movies handler
 * - Uses first genre from movie to find related movies
 */

import { CONSTANTS } from "../config.js";
import { fetchText } from "../utils/fetch.js";
import { sendMessage } from "../services/telegram.js";
import { cache, createMovieList } from "../services/cache.js";
import { parseMovieList } from "../parsers/movieList.js";
import { esc } from "../utils/text.js";

export async function handleSimilar(config, chatId, slug, reqId) {
  const details = await cache.getJson(config.cacheKv, `movie:${slug}`);
  if (!details || details.genres.length === 0) {
    await sendMessage(config.botToken, chatId, "❌ Similar movies এর জন্য genre info নেই");
    return;
  }
  const genre = details.genres.find((g) =>
    /^(korea|eng[- ]?sub|censored|uncensored|japan|china|western)$/i.test(g)
  ) || details.genres[0];
  const genreSlug = genre.toLowerCase().replace(/\s+/g, "-");
  const searchUrl = `${CONSTANTS.KRX_BASE}/genre/${genreSlug}/`;

  const r = await fetchText(searchUrl);
  if (!r.ok) {
    await sendMessage(config.botToken, chatId, "❌ Similar movies fetch করা যায়নি");
    return;
  }
  const movies = parseMovieList(r.text).filter((m) => m.slug !== slug).slice(0, CONSTANTS.MOVIES_PER_PAGE);
  if (movies.length === 0) {
    await sendMessage(config.botToken, chatId, "❌ Similar movies পাওয়া যায়নি");
    return;
  }
  const keyboard = [];
  const slugs = movies.map(m => m.slug);
  const listId = await createMovieList(config.cacheKv, slugs);
  for (let i = 0; i < movies.length; i += 2) {
    const row = [];
    for (let j = i; j < Math.min(i + 2, movies.length); j++) {
      const title = movies[j].title.length > 30
        ? movies[j].title.slice(0, 30) + "…"
        : movies[j].title;
      row.push({ text: `🎬 ${title}`, callback_data: `movie:${listId}:${j}` });
    }
    keyboard.push(row);
  }
  await sendMessage(
    config.botToken, chatId,
    `🎭 <b>Similar movies</b> (${esc(genre)})`,
    { parse_mode: "HTML", reply_markup: { inline_keyboard: keyboard } }
  );
}
