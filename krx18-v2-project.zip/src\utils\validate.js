/**
 * Validation helpers
 * - URL safety
 * - Slug pattern
 * - Filter check
 * - Callback data size
 */

import { FILTERS } from "../config.js";

export function isValidUrl(s) {
  if (!s || typeof s !== "string") return false;
  try {
    const u = new URL(s);
    return u.protocol === "https:" || u.protocol === "http:";
  } catch {
    return false;
  }
}

export function isValidSlug(slug) {
  if (!slug) return false;
  // Allow letters, digits, hyphens — reject path traversal / weird chars
  return /^[a-z0-9][a-z0-9\-]{2,200}$/i.test(slug);
}

export function isValidFilter(filter) {
  if (!filter) return false;
  return FILTERS.has(filter.toLowerCase());
}

export function isValidPage(page) {
  const n = Number(page);
  return Number.isInteger(n) && n > 0 && n < 1000;
}

// Telegram callback_data max = 64 bytes
export function safeCallback(data) {
  if (typeof data !== "string") return null;
  if (data.length > 64) return null;
  return data;
}

// Ensure callback_data fits within 64 bytes by truncating slug
export function fitCallback(prefix, slug) {
  const maxSlug = 64 - prefix.length;
  if (maxSlug < 4) return null;
  return prefix + slug.slice(0, maxSlug);
}

export function sanitizeRequestText(text) {
  if (!text) return "";
  return text.trim().slice(0, 500);
}
