/**
 * Webhook security middleware
 * - Validates ?token= query param against WEBHOOK_SECRET (if set)
 */

export function checkWebhookSecret(config, url) {
  if (!config.webhookSecret) return true;
  const token = url.searchParams.get("token");
  return token === config.webhookSecret;
}
