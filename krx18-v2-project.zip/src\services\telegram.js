/**
 * Telegram Bot API client
 * - sendMessage, editMessageText, sendPhoto, answerCallbackQuery, answerInlineQuery
 * - Centralized error handling
 */

import { CONSTANTS } from "../config.js";
import * as logger from "../utils/logger.js";

async function tgCall(token, method, body) {
  if (!token) {
    logger.warn("tgCall: BOT_TOKEN missing", { method });
    return { ok: false, error: "BOT_TOKEN missing" };
  }
  try {
    const r = await fetch(`${CONSTANTS.TG_API_BASE}${token}/${method}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    return await r.json();
  } catch (e) {
    logger.error("tgCall failed", { method, error: String(e) });
    return { ok: false, error: String(e) };
  }
}

export function sendMessage(token, chatId, text, extra = {}) {
  return tgCall(token, "sendMessage", { chat_id: chatId, text, ...extra });
}

export function editMessageText(token, chatId, messageId, text, extra = {}) {
  return tgCall(token, "editMessageText", {
    chat_id: chatId,
    message_id: messageId,
    text,
    ...extra,
  });
}

export function sendPhoto(token, chatId, photo, caption, extra = {}) {
  return tgCall(token, "sendPhoto", {
    chat_id: chatId,
    photo,
    caption,
    ...extra,
  });
}

export function answerCallback(token, callbackId, text = "") {
  return tgCall(token, "answerCallbackQuery", {
    callback_query_id: callbackId,
    text,
  });
}

export function answerInline(token, inlineId, results, extra = {}) {
  return tgCall(token, "answerInlineQuery", {
    inline_query_id: inlineId,
    results,
    cache_time: 300,
    is_personal: false,
    ...extra,
  });
}

// Try sending a photo, fall back to text if photo fails (e.g. broken URL)
export async function sendPhotoOrText(token, chatId, photoUrl, text, extra = {}) {
  if (photoUrl) {
    try {
      const r = await sendPhoto(token, chatId, photoUrl, text, extra);
      if (r.ok) return r;
    } catch (e) {
      logger.warn("sendPhoto failed, falling back to text", { error: String(e) });
    }
  }
  return sendMessage(token, chatId, text, extra);
}

export function sendMediaGroup(token, chatId, media, extra = {}) {
  return tgCall(token, "sendMediaGroup", {
    chat_id: chatId,
    media,
    ...extra,
  });
}
