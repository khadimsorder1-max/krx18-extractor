/**
 * KRX18 Video URL Extractor (Puppeteer) — modular version
 * ========================================================
 *
 * Flow:
 *   1. Extract post_id from movie URL
 *   2. Call Dooplayer API → iframe URL
 *   3. Open iframe with Puppeteer (stealth + adblocker)
 *   4. Intercept network → capture .mp4 / .m3u8
 *   5. Fall back to JWPlayer eval + API responses
 *   6. Try Server 2 if Server 1 fails
 *   7. Edit Telegram message with the result
 *
 * Modules:
 *   - browser.js   → launchBrowser (Chromium + stealth + adblocker)
 *   - capture.js   → network interception + JWPlayer eval
 *   - notify.js    → Telegram sendMessage / editMessage
 */

const { launchBrowser } = require("./browser");
const { setupCapture, tryJwPlayerEval, extractFromApiResponses } = require("./capture");
const { sendMessage, editMessage } = require("./notify");

const MOVIE_URL = process.env.MOVIE_URL;
const SERVER = process.env.SERVER || "1";
const MESSAGE_ID = process.env.MESSAGE_ID;

const PLAY_SELECTORS = [
  ".jw-icon.jw-icon-display",
  ".jw-display-icon-display",
  ".jw-icon-playback",
  ".vjs-big-play-button",
  "video",
  ".vp-preview",
  "[class*='play']",
  "#overlay",
  ".play-button",
];

async function main() {
  console.log("=== KRX18 Video URL Extractor ===");
  console.log(`Movie URL: ${MOVIE_URL}`);
  console.log(`Server: ${SERVER}`);

  if (!MOVIE_URL) {
    console.error("MOVIE_URL env var not set");
    process.exit(1);
  }

  // Send processing message
  const procMsg = await sendMessage(
    `⏳ *ভিডিও URL বের করা হচ্ছে...*\n\n` +
    `🎬 Server ${SERVER}\n` +
    `🔄 Browser খোলা হচ্ছে...\n` +
    `⏱️ সময় লাগবে 30-60 সেকেন্ড`,
    { parse_mode: "Markdown" }
  );
  const procMessageId = procMsg?.result?.message_id || MESSAGE_ID;

  const browser = await launchBrowser();
  const videoUrls = [];
  const apiResponses = [];

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1280, height: 720 });
    await page.setUserAgent(
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
      "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    );
    setupCapture(page, browser, videoUrls, apiResponses);

    // Step 1: post_id
    const postIdM = MOVIE_URL.match(/\/movies\/(\d+)-/);
    if (!postIdM) throw new Error("Could not extract post ID from URL: " + MOVIE_URL);
    const postId = postIdM[1];
    console.log(`Post ID: ${postId}`);

    // Step 2: Dooplayer API
    await editMessage(procMessageId,
      `⏳ *ভিডিও URL বের করা হচ্ছে...*\n\n` +
      `✅ Browser খোলা হয়েছে\n` +
      `🔄 Dooplayer API call করা হচ্ছে...\n` +
      `⏱️ অপেক্ষা করুন`,
      { parse_mode: "Markdown" }
    );

    const iframeUrl = await fetchIframeUrl(browser, postId, MOVIE_URL, SERVER);
    if (!iframeUrl) throw new Error(`No embed_url for server ${SERVER}`);
    console.log(`Iframe URL: ${iframeUrl}`);

    // Step 3: Open iframe
    await editMessage(procMessageId,
      `⏳ *ভিডিও URL বের করা হচ্ছে...*\n\n` +
      `✅ Iframe URL পাওয়া গেছে\n` +
      `🔄 Player লোড হচ্ছে...\n` +
      `⏱️ অপেক্ষা করুন`,
      { parse_mode: "Markdown" }
    );

    await page.goto(iframeUrl, { waitUntil: "domcontentloaded", timeout: 30000 });
    await sleep(5000);

    // Step 4: Trigger playback
    await triggerPlay(page);

    // Step 5: Wait for video URL
    await editMessage(procMessageId,
      `⏳ *ভিডিও URL বের করা হচ্ছে...*\n\n` +
      `✅ Player লোড হয়েছে\n` +
      `🔄 Video URL capture হচ্ছে...\n` +
      `⏱️ অপেক্ষা করুন`,
      { parse_mode: "Markdown" }
    );

    await waitForVideoUrl(page, videoUrls, 30);

    // Step 6: Fall back to API responses
    if (videoUrls.length === 0 && apiResponses.length > 0) {
      const url = extractFromApiResponses(apiResponses);
      if (url) videoUrls.push({ url, type: "api", time: Date.now() });
    }

    // Step 7: Fall back to JWPlayer eval
    if (videoUrls.length === 0) {
      const url = await tryJwPlayerEval(page);
      if (url) videoUrls.push({ url, type: "eval", time: Date.now() });
    }

    // Step 8: Try Server 2 if Server 1 failed
    if (videoUrls.length === 0 && SERVER === "1") {
      console.log("Server 1 failed, trying Server 2...");
      const iframe2 = await fetchIframeUrl(browser, postId, MOVIE_URL, "2");
      if (iframe2) {
        await page.goto(iframe2, { waitUntil: "domcontentloaded", timeout: 30000 });
        await sleep(5000);
        await triggerPlay(page);
        await waitForVideoUrl(page, videoUrls, 20);
      }
    }

    await browser.close();

    // Step 9: Send result
    if (videoUrls.length === 0) {
      await editMessage(procMessageId,
        `⚠️ *Direct URL বের করা যায়নি*\n\n` +
        `কারণ: Player JavaScript আটকে গেছে\n\n` +
        `🔗 *বিকল্প — ব্রাউজারে খুলুন:*`,
        {
          parse_mode: "Markdown",
          reply_markup: {
            inline_keyboard: [[{ text: "🌐 Server 1 (playkrx18)", url: iframeUrl }]],
          },
        }
      );
      process.exit(0);
    }

    const uniqueUrls = [...new Set(videoUrls.map((v) => v.url))];
    const bestUrl = uniqueUrls[0];
    console.log(`\n=== FINAL ===\nBest URL: ${bestUrl}\nAll: ${uniqueUrls.join("\n")}`);

    await sendResult(procMessageId, bestUrl, uniqueUrls, iframeUrl);
    console.log("Done!");
  } catch (err) {
    console.error("Error:", err);
    try { await browser.close(); } catch {}
    await editMessage(procMessageId,
      `❌ *Error:*\n\`${String(err.message).substring(0, 200)}\``,
      { parse_mode: "Markdown" }
    );
    process.exit(1);
  }
}

// ─── Helpers ────────────────────────────────────────────────────

async function fetchIframeUrl(browser, postId, movieUrl, server) {
  const apiUrl = `https://krx18.com/wp-json/dooplayer/v2/${postId}/movie/${server}`;
  const apiPage = await browser.newPage();
  await apiPage.setExtraHTTPHeaders({ Referer: movieUrl });
  try {
    const resp = await apiPage.goto(apiUrl, { waitUntil: "domcontentloaded", timeout: 20000 });
    const text = await resp.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      // Cloudflare challenge — visit movie page first
      await apiPage.goto(movieUrl, { waitUntil: "domcontentloaded", timeout: 20000 });
      await sleep(3000);
      const retry = await apiPage.goto(apiUrl, { waitUntil: "domcontentloaded", timeout: 20000 });
      data = JSON.parse(await retry.text());
    }
    return data.embed_url && data.embed_url !== "null" ? data.embed_url : null;
  } finally {
    await apiPage.close();
  }
}

async function triggerPlay(page) {
  for (const sel of PLAY_SELECTORS) {
    try {
      const el = await page.$(sel);
      if (el) {
        console.log(`Clicking: ${sel}`);
        await el.click();
        return;
      }
    } catch {}
  }
  console.log("No play button found, clicking center");
  await page.mouse.click(640, 360);
}

async function waitForVideoUrl(page, videoUrls, maxSeconds) {
  let waited = 0;
  while (videoUrls.length === 0 && waited < maxSeconds) {
    await sleep(2000);
    waited += 2;
    console.log(`Waiting... (${waited}s, ${videoUrls.length} URLs)`);
    if (waited % 10 === 0) {
      try { await page.mouse.click(640, 360); } catch {}
    }
  }
}

async function sendResult(messageId, bestUrl, allUrls, fallbackIframeUrl) {
  let msg = `✅ *Direct Video URL পাওয়া গেছে\\!*\n\n`;
  msg += `🎬 *MX Player এ চালানোর নিয়ম:*\n`;
  msg += `1\\. নিচের URL copy করুন\n`;
  msg += `2\\. MX Player → ☰ → Network Stream\n`;
  msg += `3\\. Paste → Play\n\n`;
  msg += `📥 *Browser এ download:*\n`;
  msg += `URL ব্রাউজারে পেস্ট করুন\n\n`;
  msg += `*Video URL:*\n`;
  msg += `\`${escapeForMdV2(bestUrl)}\`\n`;
  if (allUrls.length > 1) {
    msg += `\n*সব URLs \\(${allUrls.length}\\):*\n`;
    for (const u of allUrls.slice(0, 5)) {
      msg += `\`${escapeForMdV2(u)}\`\n`;
    }
  }
  const keyboard = [[{ text: "🔗 Browser এ খুলুন", url: bestUrl }]];
  if (allUrls.length > 1) {
    keyboard.push([{ text: "🔗 Alt URL", url: allUrls[1] }]);
  }
  await editMessage(messageId, msg, {
    parse_mode: "MarkdownV2",
    disable_web_page_preview: true,
    reply_markup: { inline_keyboard: keyboard },
  });
}

function escapeForMdV2(s) {
  return s.replace(/([_*`\[\]()~>#+\-=|{}.!\\])/g, "\\$1");
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

main().catch((e) => {
  console.error("Fatal:", e);
  process.exit(1);
});
