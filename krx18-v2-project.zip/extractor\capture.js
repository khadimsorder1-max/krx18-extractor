/**
 * Video URL capture module
 * - Intercepts network requests
 * - Captures .mp4 / .m3u8 / .mkv / .webm
 * - Tries JWPlayer page evaluation as fallback
 */

const VIDEO_EXT_RE = /\.(mp4|m3u8|mkv|webm)(\?|$)/i;
const API_HOST_RE = /(api-play|tp1rd|iamcdn|abyss)/i;

function setupCapture(page, browser, videoUrls, apiResponses) {
  page.on("request", (req) => {
    const url = req.url();
    if (VIDEO_EXT_RE.test(url) && !url.includes("favicon")) {
      console.log(`[VIDEO REQUEST] ${url}`);
      videoUrls.push({ url, type: "request", time: Date.now() });
    }
  });

  page.on("response", async (response) => {
    const url = response.url();
    if (VIDEO_EXT_RE.test(url) && !url.includes("favicon")) {
      console.log(`[VIDEO RESPONSE] ${url} (status: ${response.status()})`);
      videoUrls.push({ url, type: "response", time: Date.now() });
    }
    if (API_HOST_RE.test(url)) {
      try {
        const text = await response.text();
        console.log(`[API RESPONSE] ${url}: ${text.substring(0, 500)}`);
        apiResponses.push({ url, text, time: Date.now() });
      } catch {
        console.log(`[API RESPONSE] ${url}: (could not read body)`);
      }
    }
  });

  browser.on("targetcreated", async (target) => {
    const popupUrl = target.url();
    if (VIDEO_EXT_RE.test(popupUrl)) {
      console.log(`[POPUP VIDEO] ${popupUrl}`);
      videoUrls.push({ url: popupUrl, type: "popup", time: Date.now() });
    }
  });
}

async function tryJwPlayerEval(page) {
  try {
    return await page.evaluate(() => {
      if (typeof jwplayer !== "undefined") {
        const p = jwplayer();
        if (p && p.getPlaylist) {
          const pl = p.getPlaylist();
          if (pl && pl[0]) {
            return (
              pl[0].file ||
              (pl[0].sources && pl[0].sources[0] && pl[0].sources[0].file)
            );
          }
        }
      }
      const video = document.querySelector("video");
      if (video && video.src) return video.src;
      if (video && video.querySelector("source")) {
        return video.querySelector("source").src;
      }
      return null;
    });
  } catch (e) {
    console.log("JWPlayer eval failed:", e.message);
    return null;
  }
}

function extractFromApiResponses(apiResponses) {
  for (const api of apiResponses) {
    // Try JSON
    try {
      const data = JSON.parse(api.text);
      const url =
        data.playlist || data.file || data.url ||
        (data.sources && data.sources[0] && data.sources[0].file) ||
        (data.data && data.data.playlist);
      if (url && typeof url === "string" && url.startsWith("http")) {
        return url;
      }
    } catch {}
    // Try regex
    const m = api.text.match(
      /https?:\/\/[^"'\s<>]+\.(?:mp4|m3u8|mkv|webm)[^"'\s<>]*/i
    );
    if (m) return m[0];
  }
  return null;
}

module.exports = { setupCapture, tryJwPlayerEval, extractFromApiResponses };
