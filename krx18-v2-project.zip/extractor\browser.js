/**
 * Browser launcher
 * - puppeteer-extra + stealth + adblocker
 * - Brave alternative via env.PUPPETEER_EXECUTABLE_PATH
 */

const puppeteer = require("puppeteer-extra");
const StealthPlugin = require("puppeteer-extra-plugin-stealth");
const AdblockerPlugin = require("puppeteer-extra-plugin-adblocker");

// Apply plugins once
puppeteer.use(StealthPlugin());
puppeteer.use(AdblockerPlugin({ blockTrackers: true }));

async function launchBrowser() {
  return puppeteer.launch({
    headless: "new",
    executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || undefined,
    args: [
      "--no-sandbox",
      "--disable-setuid-sandbox",
      "--disable-dev-shm-usage",
      "--disable-gpu",
      "--mute-audio",
      "--disable-popup-blocking",
      "--window-size=1280,720",
    ],
  });
}

module.exports = { launchBrowser };
