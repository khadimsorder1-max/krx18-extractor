/**
 * Telegram notification helpers for the extractor
 * - sendMessage, editMessageText
 * - Used by extract.js to update the user's processing message with the result
 */

async function tgCall(method, body) {
  const token = process.env.BOT_TOKEN;
  const chatId = process.env.CHAT_ID;
  if (!token || !chatId) return null;
  try {
    const r = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, ...body }),
    });
    return await r.json();
  } catch (e) {
    console.error("Telegram call failed:", e.message);
    return null;
  }
}

async function sendMessage(text, extra = {}) {
  return tgCall("sendMessage", { text, ...extra });
}

async function editMessage(messageId, text, extra = {}) {
  if (!messageId) return null;
  return tgCall("editMessageText", { message_id: parseInt(messageId, 10), text, ...extra });
}

module.exports = { sendMessage, editMessage };
