/**
 * /request handler
 * - Forwards movie request to admin
 */

import { sendMessage } from "../services/telegram.js";
import { sanitizeRequestText } from "../utils/validate.js";

function esc(s) {
  if (!s) return "";
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

export async function handleRequest(config, chatId, requestText, userId, username) {
  if (!config.adminChatId) {
    await sendMessage(config.botToken, chatId, "❌ Admin configured নন");
    return;
  }
  const clean = sanitizeRequestText(requestText);
  if (clean.length < 2) {
    await sendMessage(
      config.botToken, chatId,
      "❌ Movie name দাও। উদাহরণ: /request Massage Room 2"
    );
    return;
  }
  const userName = username ? `@${username}` : `User ${userId}`;
  await sendMessage(
    config.botToken, config.adminChatId,
    `📨 <b>New Movie Request</b>\n\n👤 From: ${esc(userName)}\n🆔 ID: <code>${userId}</code>\n\n🎬 Movie: ${esc(clean)}`,
    { parse_mode: "HTML" }
  );
  await sendMessage(
    config.botToken, chatId,
    `✅ তোমার request admin কে পাঠানো হয়েছে!\n\n🎬 ${esc(clean)}`,
    { parse_mode: "HTML" }
  );
}
