/**
 * Fetch helper with retry + timeout.
 * Used by Worker for HTML scraping + JSON API calls.
 */

import { CONSTANTS } from "../config.js";

async function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

/**
 * Fetch text with retry on 5xx.
 * Returns { ok, status, text, error }
 */
export async function fetchText(url, options = {}) {
  const {
    headers = {},
    timeoutMs = CONSTANTS.FETCH_TIMEOUT_MS,
    retries = CONSTANTS.FETCH_RETRIES,
    accept = "text/html,application/xhtml+xml",
  } = options;

  let lastErr = null;
  for (let attempt = 0; attempt <= retries; attempt++) {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const r = await fetch(url, {
        headers: {
          "User-Agent": CONSTANTS.USER_AGENT,
          Accept: accept,
          ...headers,
        },
        signal: ctrl.signal,
        redirect: "follow",
      });
      if (!r.ok) {
        // Retry on 5xx, otherwise give up immediately
        if (attempt < retries && r.status >= 500) {
          await sleep(CONSTANTS.FETCH_RETRY_BASE_MS * (attempt + 1));
          continue;
        }
        return { ok: false, status: r.status, text: "" };
      }
      return { ok: true, status: r.status, text: await r.text() };
    } catch (e) {
      lastErr = String(e);
      clearTimeout(t);
      if (attempt < retries) {
        await sleep(CONSTANTS.FETCH_RETRY_BASE_MS * (attempt + 1));
        continue;
      }
      return { ok: false, status: 0, text: "", error: lastErr };
    } finally {
      clearTimeout(t);
    }
  }
  return { ok: false, status: 0, text: "", error: lastErr };
}

/**
 * Fetch binary (for image proxy).
 */
export async function fetchBinary(url, options = {}) {
  const {
    headers = {},
    timeoutMs = CONSTANTS.IMG_TIMEOUT_MS,
  } = options;
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(url, {
      headers: { "User-Agent": CONSTANTS.USER_AGENT, ...headers },
      signal: ctrl.signal,
      redirect: "follow",
    });
    if (!r.ok) return { ok: false, status: r.status, body: null, contentType: "" };
    const body = await r.arrayBuffer();
    return {
      ok: true,
      status: r.status,
      body,
      contentType: r.headers.get("Content-Type") || "",
    };
  } catch (e) {
    return { ok: false, status: 0, body: null, contentType: "", error: String(e) };
  } finally {
    clearTimeout(t);
  }
}

/**
 * Head-like check (Range 0-0 GET).
 */
export async function fetchHead(url, options = {}) {
  const { headers = {}, timeoutMs = CONSTANTS.HEAD_TIMEOUT_MS } = options;
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(url, {
      method: "GET",
      headers: { "User-Agent": CONSTANTS.USER_AGENT, Range: "bytes=0-0", ...headers },
      signal: ctrl.signal,
      redirect: "follow",
    });
    return {
      ok: r.ok,
      status: r.status,
      contentType: r.headers.get("Content-Type") || "",
      contentRange: r.headers.get("Content-Range") || "",
      contentLength: r.headers.get("Content-Length") || "",
    };
  } catch (e) {
    return { ok: false, status: 0, error: String(e) };
  } finally {
    clearTimeout(t);
  }
}
