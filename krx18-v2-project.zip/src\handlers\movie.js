/**
 * Movie details handler
 * - Fetches + parses movie page
 * - Sends poster + rich caption
 * - Shows download buttons + Watch Online Direct (if GitHub configured)
 */

import { CONSTANTS } from "../config.js";
import { fetchText } from "../utils/fetch.js";
import { truncate, esc } from "../utils/text.js";
import { sendMessage, sendPhotoOrText } from "../services/telegram.js";
import { cache, createMovieList } from "../services/cache.js";
import { recordDownload } from "../services/stats.js";
import { parseMovieDetails } from "../parsers/movieDetails.js";
import * as logger from "../utils/logger.js";

export async function handleMovieDetails(config, chatId, slug, userId, reqId) {
  const movieUrl = `${CONSTANTS.KRX_BASE}/movies/${slug}/`;
  const cacheKey = `movie:${slug}`;

  let details = await cache.getJson(config.cacheKv, cacheKey);
  if (!details) {
    logger.info("Fetching movie details", { slug, url: movieUrl }, reqId);
    const r = await fetchText(movieUrl);
    if (!r.ok) {
      await sendMessage(config.botToken, chatId, "❌ Movie details fetch করা যায়নি");
      return;
    }
    details = parseMovieDetails(r.text);
    details.movieUrl = movieUrl;
    await cache.setJson(config.cacheKv, cacheKey, details, CONSTANTS.CACHE_TTL * 4);
  }

  const caption = buildCaption(details);
  await sendPhotoOrText(
    config.botToken, chatId, details.poster, caption,
    { parse_mode: "HTML" }
  );

  if (details.trailer) {
    await sendMessage(
      config.botToken, chatId, "🔗 <b>External links:</b>",
      {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "▶️ Trailer", url: details.trailer }]] },
      }
    );
  }

  if (details.downloads.length === 0) {
    await sendMessage(config.botToken, chatId, "❌ এই movie এর download link পাওয়া যায়নি");
    return;
  }

  const keyboard = await buildDownloadKeyboard(details, slug, config);
  const dlText = buildDownloadText(config);

  await sendMessage(config.botToken, chatId, dlText, {
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: keyboard },
  });

  if (userId && details.downloads[0]) {
    await recordDownload(config.cacheKv, userId, details.downloads[0].host);
  }
}

function buildCaption(d) {
  let caption = `🎬 <b>${esc(d.title)}</b>\n`;
  if (d.koreanTitle) caption += `🇰🇷 ${esc(d.koreanTitle)}\n`;
  caption += "\n📋 <b>Info:</b>\n";
  if (d.country) caption += `🌍 Country: ${esc(d.country)}\n`;
  if (d.quality) caption += `🎥 Quality: ${esc(d.quality)}\n`;
  if (d.releaseDate) caption += `📅 Release: ${esc(d.releaseDate)}\n`;
  if (d.genres.length > 0) caption += `🎭 Genres: ${esc(d.genres.join(", "))}\n`;
  caption += "\n";
  if (d.actors.length > 0) {
    caption += `👥 <b>Cast:</b>\n${esc(d.actors.slice(0, 5).join(", "))}\n\n`;
  }
  if (d.description) {
    caption += `📖 <b>Synopsis:</b>\n${esc(truncate(d.description, CONSTANTS.MAX_SYNOPSIS_LEN))}\n`;
  }
  if (caption.length > CONSTANTS.MAX_CAPTION_LEN) {
    caption = caption.slice(0, CONSTANTS.MAX_CAPTION_LEN - 1) + "…";
  }
  return caption;
}

async function buildDownloadKeyboard(d, slug, config) {
  const keyboard = [];

  for (const dl of d.downloads) {
    const label = dl.quality
      ? `${dl.quality} (${dl.host})`
      : `Download (${dl.host})`;
    keyboard.push([{ text: `⬇️ ${label}`, url: dl.url }]);
  }

  if (d.genres.length > 0) {
    const simListId = await createMovieList(config.cacheKv, [slug]);
    keyboard.push([{ text: "🎭 Similar Movies", callback_data: `similar:${simListId}:0` }]);
  }
  const favListId = await createMovieList(config.cacheKv, [`${slug}:${d.title}`]);
  keyboard.push([{ text: "⭐ Add to Favorites", callback_data: `addfav:${favListId}:0` }]);
  return keyboard;
}

function buildDownloadText(config) {
  return (
    `📥 <b>Download links:</b>\n` +
    `⚠️ Button চাপলে browser এ newsmonth.today খুলবে → সেখানে আসল file host (k2s.cc / nitroflare / alterupload) এ যাবে।\n\n` +
    `যে host চাও সেটা select করো:`
  );
}
