/**
 * /start, /help handler
 */

import { sendMessage } from "../services/telegram.js";

export async function handleStart(config, chatId) {
  const text =
    `<b>🎬 KRX18 Korea Bot v2</b>\n\n` +
    `আমি তোমার KRX18 Korea movie bot!\n\n` +
    `<b>Commands:</b>\n` +
    `/start — এই message\n` +
    `/latest [filter] — latest 10 Korean movies\n` +
    `  Filters: eng-sub, censored, uncensored, hd, korea\n` +
    `/latest 2 — page 2, 3, etc.\n` +
    `/search query — search\n` +
    `/movie url — specific movie details\n` +
    `/fav slug — add to favorites\n` +
    `/favs — favorite list\n` +
    `/unfav slug — remove favorite\n` +
    `/request name — request admin\n` +
    `/stats — download stats\n\n` +
    `<b>Inline mode:</b> @your_bot query\n\n` +
    `<b>Features:</b>\n` +
    `✅ Poster, cast, synopsis, Korean title\n` +
    `✅ Auto-notify new releases\n` +
    `✅ Favorites, similar movies\n` +
    `✅ Direct stream (GitHub Actions + Puppeteer)\n` +
    `✅ Download (newsmonth redirect)`;

  await sendMessage(config.botToken, chatId, text, { parse_mode: "HTML" });
}
