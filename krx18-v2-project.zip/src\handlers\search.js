/**
 * /search handler + inline mode
 * - Poster gallery (media group) + numbered keyboard
 */

import { CONSTANTS } from "../config.js";
import { fetchText } from "../utils/fetch.js";
import { sendMessage, sendPhoto, sendMediaGroup, answerInline } from "../services/telegram.js";
import { parseMovieList } from "../parsers/movieList.js";
import { createMovieList } from "../services/cache.js";
import { esc, proxyPoster } from "../utils/text.js";

export async function handleSearch(config, chatId, query) {
  if (!query || query.length < 2) {
    await sendMessage(
      config.botToken, chatId,
      "❌ Search query দাও। উদাহরণ: /search Massage"
    );
    return;
  }
  const searchUrl = `${CONSTANTS.KRX_BASE}/?s=${encodeURIComponent(query)}`;
  const r = await fetchText(searchUrl);
  if (!r.ok) {
    await sendMessage(config.botToken, chatId, "❌ Search failed");
    return;
  }
  const movies = parseMovieList(r.text);
  if (movies.length === 0) {
    await sendMessage(
      config.botToken, chatId,
      `❌ "${esc(query)}" এর জন্য কিছু পাওয়া যায়নি`
    );
    return;
  }
  const top = movies.slice(0, CONSTANTS.MOVIES_PER_PAGE);
  const listId = await createMovieList(config.cacheKv, top.map(m => m.slug));

  // Step 1: Send poster gallery
  await sendGallery(config, chatId, top);

  // Step 2: Send numbered keyboard
  await sendKeyboard(config, chatId, top, listId, query);
}

async function sendGallery(config, chatId, movies) {
  const workerUrl = config.workerUrl || "";
  const media = movies.map((m, i) => {
    const photo = m.poster ? proxyPoster(m.poster, workerUrl) : "";
    const parts = [];
    parts.push(`${i + 1}/${movies.length} 🎬 <b>${esc(m.title)}</b>`);
    if (m.year || m.releaseDate) parts.push(`📅 ${esc(m.year || m.releaseDate)}`);
    if (m.quality) parts.push(`🎥 ${esc(m.quality)}`);
    if (m.genres && m.genres.length > 0) parts.push(`🎭 ${esc(m.genres.slice(0, 3).join(", "))}`);
    if (m.synopsis) {
      const syn = m.synopsis.length > 150 ? m.synopsis.slice(0, 150) + "…" : m.synopsis;
      parts.push(`\n📖 ${esc(syn)}`);
    }

    const item = {
      type: "photo",
      caption: parts.join("\n"),
      parse_mode: "HTML",
    };
    if (photo) {
      item.photo = photo;
    } else {
      item.photo = "https://via.placeholder.com/300x450?text=No+Poster";
    }
    return item;
  });

  if (media.length >= 2) {
    const result = await sendMediaGroup(config.botToken, chatId, media);
    if (!result.ok) {
      // Fallback: send first photo only
      if (media[0]) {
        await sendPhoto(config.botToken, chatId, media[0].photo, media[0].caption, { parse_mode: "HTML" });
      }
    }
  } else if (media.length === 1) {
    await sendPhoto(config.botToken, chatId, media[0].photo, media[0].caption, { parse_mode: "HTML" });
  }
}

async function sendKeyboard(config, chatId, movies, listId, query) {
  const keyboard = buildKeyboard(movies, listId);

  await sendMessage(
    config.botToken,
    chatId,
    `🔍 <b>Search: "${esc(query)}"</b> — ${movies.length} found\n\n` +
    `বাটনে চাপো movie details দেখতে:`,
    { parse_mode: "HTML", reply_markup: { inline_keyboard: keyboard } }
  );
}

function buildKeyboard(movies, listId) {
  const emojis = ["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣","🔟"];
  const keyboard = [];
  for (let i = 0; i < movies.length; i += 5) {
    const row = [];
    for (let j = i; j < Math.min(i + 5, movies.length); j++) {
      const title = movies[j].title.length > 20
        ? movies[j].title.slice(0, 20) + "…"
        : movies[j].title;
      row.push({
        text: `${emojis[j]} ${title}`,
        callback_data: `mlist:${listId}:${j}`,
      });
    }
    keyboard.push(row);
  }
  return keyboard;
}

export async function handleInline(config, inlineQuery) {
  const query = (inlineQuery.query || "").trim();
  if (query.length < 2) {
    return answerInline(config.botToken, inlineQuery.id, [], { cache_time: 60 });
  }
  const searchUrl = `${CONSTANTS.KRX_BASE}/?s=${encodeURIComponent(query)}`;
  const r = await fetchText(searchUrl);
  if (!r.ok) {
    return answerInline(config.botToken, inlineQuery.id, [], { cache_time: 60 });
  }
  const movies = parseMovieList(r.text).slice(0, 20);
  const slugs = movies.map(m => m.slug);
  const listId = await createMovieList(config.cacheKv, slugs);
  const results = movies.map((m, i) => ({
    type: "article",
    id: `${m.slug}_${i}`,
    title: m.title,
    description: m.synopsis ? m.synopsis.slice(0, 100) : `Release: ${m.releaseDate}`,
    thumb_url: m.poster,
    input_message_content: {
      message_text: `🎬 ${m.title}${m.releaseDate ? `\n📅 ${m.releaseDate}` : ""}\n\n🔗 ${m.url}`,
    },
    reply_markup: {
      inline_keyboard: [[{ text: "🎬 View Details", callback_data: `mlist:${listId}:${i}` }]],
    },
  }));
  return answerInline(config.botToken, inlineQuery.id, results);
}
