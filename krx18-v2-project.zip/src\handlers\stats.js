/**
 * /stats handler
 */

import { sendMessage } from "../services/telegram.js";
import { getStats } from "../services/stats.js";

export async function handleStats(config, chatId) {
  const stats = await getStats(config.cacheKv);
  if (!stats) {
    await sendMessage(config.botToken, chatId, "❌ Stats available না (KV configured নন)");
    return;
  }
  let text = `📊 <b>Download Stats</b>\n\n📥 Total: ${stats.total}\n\n📅 <b>Last 7 days:</b>\n`;
  for (const [date, count] of Object.entries(stats.daily)) {
    text += `  ${date}: ${count}\n`;
  }
  if (Object.keys(stats.hosts).length > 0) {
    text += `\n🌐 <b>By host:</b>\n`;
    for (const [host, count] of Object.entries(stats.hosts)) {
      text += `  ${host}: ${count}\n`;
    }
  }
  await sendMessage(config.botToken, chatId, text, { parse_mode: "HTML" });
}
