/** Webhook secret check */
export function checkWebhookSecret(config, url) {
  if (!config.webhookSecret) return true;
  const token = url.searchParams.get("token");
  return token === config.webhookSecret;
}
